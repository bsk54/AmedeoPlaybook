vocs01=`
失踪#shīzōng#to disappear; to go missing#scomparire, risultare disperso
涉嫌#shèxián#to be suspected of#essere sospettato di
贪污#tānwū#corruption; embezzlement#corruzione, appropriazione indebita
金额#jīn’é#amount of money#ammontare di denaro
配合调查#pèihé diàochá#to cooperate with an investigation#collaborare con l’indagine
出纳#chūnà#cashier; treasurer#cassiere, responsabile di cassa
审核#shěnhé#to review officially; to examine#verificare ufficialmente, controllare
签字#qiānzì#to sign; signature#firma, firmare
去向#qùxiàng#whereabouts; destination#destinazione, dove è finito
履行职责#lǚxíng zhízé#to perform one’s duties#adempiere ai propri doveri
民间借款#mínjiān jièkuǎn#private loan#prestito privato
担保人#dānbǎorén#guarantor#garante
隐瞒#yǐnmán#to conceal; to hide#nascondere, occultare
共犯#gòngfàn#accomplice#correo
法律后果#fǎlǜ hòuguǒ#legal consequences#conseguenze legali
`;

vocs02=`
宿舍#sùshè#dormitory; living quarters#dormitorio, alloggio
换身衣服#huàn shēn yīfu#to change clothes#cambiarsi d’abito, cambiarsi i vestiti
局里#jú lǐ#in the bureau; in the department#nell’ufficio, nel dipartimento
提干#tígàn#promotion to a cadre position#promozione a quadro, avanzamento di carriera
考核#kǎohé#assessment; evaluation#valutazione, esame di idoneità
关键时候#guānjiàn shíhòu#critical moment; crucial time#momento cruciale, momento decisivo
耽误#dānwù#to delay; to hold up; to hinder#ritardare, compromettere
紧急开会#jǐnjí kāi huì#emergency meeting#riunione d’emergenza
处理意见#chǔlǐ yìjiàn#official handling decision; proposed disposition#orientamento decisionale ufficiale, linea di gestione
乐观#lèguān#optimistic#ottimistico
捅篓子#tǒng lǒu zi#to mess up badly; to cause big trouble#combinare un grosso guaio, fare un disastro
一走了之#yí zǒu liǎo zhī#to leave and wash one’s hands of it#andarsene senza assumersi responsabilità
担责#dānzé#to take responsibility; be held accountable#assumersi una responsabilità, rispondere delle conseguenze
有史以来#yǒu shǐ yǐ lái#ever since records began; in history#da quando esiste una storia, mai prima d’ora
贪污犯#tānwū fàn#embezzler; corruption criminal#criminale per corruzione
`;

vocs03=`
渎职#dúzhí#dereliction of duty; abuse of office#abuso d’ufficio, negligenza nel dovere
渎职罪#dúzhí zuì#crime of dereliction of duty#reato di abuso d’ufficio
零容忍#líng róngrěn#zero tolerance#tolleranza zero
坐牢#zuòláo#to go to prison; to be jailed#finire in prigione, andare in carcere
瞅瞅#chǒu chǒu#to take a look; to peek#dare un’occhiata, sbirciare
兴许#xīngxǔ#maybe; perhaps#forse, è possibile che
有所帮助#yǒu suǒ bāngzhù#to be of help; to help somewhat#essere di aiuto, risultare utile
炎热#yánrè#sweltering; very hot#molto caldo, afoso
直到#zhídào#until#fino a, fino al momento in cui
等到#děngdào#to wait until; to manage to wait until#riuscire ad aspettare fino a
留学#liúxué#to study abroad#studiare all’estero
愿望#yuànwàng#wish; aspiration#desiderio, aspirazione
专心#zhuānxīn#to focus; to concentrate#concentrarsi, dedicarsi completamente
学业#xuéyè#studies; academic work#studi, percorso di studi, carriera scolastica
`;

vocs04=`
病情#bìngqíng#medical condition; illness condition#condizioni di salute, stato della malattia
突然#tūrán#suddenly; all of a sudden#improvvisamente, all’improvviso
贵姓#guìxìng#what is your surname? (polite)#qual è il suo cognome, formula cortese
告辞#gàocí#to take one’s leave#congedarsi, accomiatarsi
接风#jiēfēng#welcome banquet for a returnee#dare il benvenuto a qualcuno appena arrivato
终于#zhōngyú#finally; at last#finalmente, alla fine
箱子#xiāngzi#box; suitcase; trunk#valigia, cassa
沉#chén#heavy#pesante
医疗器材#yīliáo qìcái#medical equipment; medical devices#attrezzature mediche, strumenti sanitari
拎#līn#to carry by hand#portare in mano, reggere un peso
风浪#fēnglàng#wind and waves; rough seas#mare mosso, onde e vento
处理好了#chǔlǐ hǎo le#to have handled/settled (it) completely#gestire e sistemare tutto, risolvere completamente
`;

vocs05=`
骑#qí#andare in bicicletta, cavalcare
陪着#péi zhe#to accompany, to stay with#accompagnare, stare accanto a qualcuno
拜访#bàifǎng#to pay a formal visit#fare visita formale, recarsi da qualcuno per rispetto
事情#shìqing#matter, affair, issue#faccenda, questione, problema
婚事#hūnshì#marriage matter, wedding business#matrimonio, questione matrimoniale, affare di nozze
学业#xuéyè#studies, academic work#studi, percorso di studi, carriera scolastica
一拖再拖#yī tuō zài tuō#to keep putting off, to delay repeatedly#rimandare continuamente, tirare per le lunghe
万一#wànyī#in case, if it should happen#nel caso che, se mai, per un’eventualità negativa
后悔#hòuhuǐ#to regret#pentirsi, provare rimorso
取消#qǔxiāo#to cancel, to call off#annullare, cancellare, revocare
`;


vocs06=`

`;

vocs07=`

`;

vocs08=`

`;

vocs09=`

`;

vocs10=`

`;

vocs11=`

`;

vocs12=`

`;

vocs13=`

`;


vocs14=`

`;


vocs15=`

`;


vocs16=`

`;

vocs17=`

`;

vocs18=`

`;

vocs19=`

`;

vocs20=`

`;

vocs21=`

`;

vocs22=`

`;

vocs23=`

`;


vocs24=`

`;


vocs25=`

`;





grammar01_2=`
<p>Hello World!</p>
`;

grammar01_2=`
<p>Hello World!</p>
`;



grammar02_2=`
<p>Hello World!</p>
`;

grammar02_2=`
<p>Hello World!</p>
`;




grammar03_2=`
<p>Hello World!</p>
`;

grammar03_2=`
<p>Hello World!</p>
`;

